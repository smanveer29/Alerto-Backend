<?php

namespace App\Http\Controllers;

use App\Models\RecordPhoto;
use App\Models\Records;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class RecordsController extends Controller
{
    public function show()
    {
        $list = Records::get();
        return response()->json($list);
    }

    public function insert(Request $req)
    {
        $val = Validator::make($req->all(), [
            "photo.*" => "required|mimes:jpg,png,jpeg|file|max:5000",
            'title'=>'required',
            "location" => "required|max:255",
            "longitude" => "required",
            "latitude" => "required",
            "pincode" => "required|integer",
        ]);
        if ($val->fails()) {
            return response()->json(['status' => false, "errors" => $val->errors()->all()]);
        }
        $photos = [];
        foreach ($req->photo as $item) {
            $path = $item->store("upload/" . now()->toDateString());
            array_push($photos, $path);
        }
        $record = Records::create($req->all());
        foreach ($photos as $photo) {
            RecordPhoto::create([
                "path" => $photo,
                "records_id" => $record->id,
            ]);
        }

        return response()->json(['status' => true, 'data' => $record]);
    }

    public function areaData(Request $req)
    {
        $val = Validator::make($req->all(), [
            'location' => 'required|exists:records,location',
        ]);
        if ($val->fails()) {
            return response()->json(['status' => false, "errors" => $val->errors()->all()]);
        }
        $getData= Records::get()->whereLocation($req->location)->all();
        return response()->json($getData);
    }
}
